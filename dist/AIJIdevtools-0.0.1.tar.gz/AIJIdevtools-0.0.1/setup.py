#!/usr/bin/env python
# coding: utf-8

from setuptools import setup

setup(
    name='AIJIdevtools',
    version='0.0.1',
    author='AIJI',
    author_email='thecrazyaiji@gmail.com',
    description='Some useful helper-funcs for devpers',
    packages=['devtools'],
    install_requires=[],
    url='https://github.com/AIJIJI/devtools'
                                                                                )
